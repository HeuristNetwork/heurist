<?php /* Smarty version Smarty-3.0.7, created on 2015-11-06 16:39:28
         compiled from "/var/www/html/HEURIST/HEURIST_FILESTORE/Shakespeares_Plays/smarty-templates/Basic list.tpl" */ ?>
<?php /*%%SmartyHeaderCode:664232481563c3d105350b6-03797142%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cafcfa8f76377204a00e7b36dc948beaeb29474e' => 
    array (
      0 => '/var/www/html/HEURIST/HEURIST_FILESTORE/Shakespeares_Plays/smarty-templates/Basic list.tpl',
      1 => 1435344365,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '664232481563c3d105350b6-03797142',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<?php  $_smarty_tpl->tpl_vars['r'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('results')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['r']->key => $_smarty_tpl->tpl_vars['r']->value){
?> 

   <!-- Output some common fields -->
   <?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>

   <?php echo $_smarty_tpl->tpl_vars['r']->value['recTitle'];?>

   <?php echo $_smarty_tpl->tpl_vars['r']->value['recURL'];?>

   <?php echo $_smarty_tpl->tpl_vars['r']->value['recModified'];?>

   <?php echo $_smarty_tpl->tpl_vars['r']->value['recWootText'];?>


   <hr> <!-- add line between each record -->

<?php }} ?> 
