<?php /* Smarty version Smarty-3.0.7, created on 2016-02-29 07:57:33
         compiled from "/var/www/html/HEURIST/HEURIST_FILESTORE/Heurist_Shakespeare_Exemplar/smarty-templates/Playlist.tpl" */ ?>
<?php /*%%SmartyHeaderCode:118029047356d35f3d53cb90-87339906%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a905089ec63f5656a166bc0347fe00bd28d7afce' => 
    array (
      0 => '/var/www/html/HEURIST/HEURIST_FILESTORE/Heurist_Shakespeare_Exemplar/smarty-templates/Playlist.tpl',
      1 => 1456693052,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '118029047356d35f3d53cb90-87339906',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>

<?php if (($_smarty_tpl->getVariable('r')->value['recTypeID']=="34")){?>
  
  
  <?php if (!isset($_smarty_tpl->tpl_vars['r']) || !is_array($_smarty_tpl->tpl_vars['r']->value)) $_smarty_tpl->createLocalArrayVariable('r');
if ($_smarty_tpl->tpl_vars['r']->value['f181']['term'] = "Comedy"){?>
  
     <?php echo $_smarty_tpl->getVariable('r')->value['f181']['term'];?>
 
  
  <?php }?>
   
  
<?php }?>
<html>


<h2>Title for report</h2> 
<hr>
<?php  $_smarty_tpl->tpl_vars['r'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('results')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['r']->key => $_smarty_tpl->tpl_vars['r']->value){
?> 
     <?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>
  
     <?php echo $_smarty_tpl->tpl_vars['r']->value['f1'];?>
       


<br/> 
<?php }} ?> 

<hr/>
<h2>End of report</h2>  
</html>
