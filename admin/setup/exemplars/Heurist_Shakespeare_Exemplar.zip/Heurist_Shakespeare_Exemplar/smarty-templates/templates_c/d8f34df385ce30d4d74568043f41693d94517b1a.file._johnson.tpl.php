<?php /* Smarty version Smarty-3.0.7, created on 2016-02-29 08:00:20
         compiled from "/var/www/html/HEURIST/HEURIST_FILESTORE/Heurist_Shakespeare_Exemplar/smarty-templates/_johnson.tpl" */ ?>
<?php /*%%SmartyHeaderCode:110058098256d35fe40ae9c1-88590021%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd8f34df385ce30d4d74568043f41693d94517b1a' => 
    array (
      0 => '/var/www/html/HEURIST/HEURIST_FILESTORE/Heurist_Shakespeare_Exemplar/smarty-templates/_johnson.tpl',
      1 => 1456693220,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '110058098256d35fe40ae9c1-88590021',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>

<?php if (($_smarty_tpl->getVariable('r')->value['recTypeID']=="34")){?>
  
  
  <?php if (($_smarty_tpl->getVariable('r')->value['f181']['term'])){?>
  
     <?php echo $_smarty_tpl->getVariable('r')->value['f181']['term'];?>
 
  
  <?php }?>
   
  
<?php }?>
<html>


<h2>Title for report</h2> 
<hr>
<?php  $_smarty_tpl->tpl_vars['r'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('results')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['r']->key => $_smarty_tpl->tpl_vars['r']->value){
?> 
     <?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>
  
     <?php echo $_smarty_tpl->tpl_vars['r']->value['f1'];?>
       


<br/> 
<?php }} ?> 

<hr/>
<h2>End of report</h2>  
</html>
