<?php /* Smarty version Smarty-3.0.7, created on 2016-02-26 13:30:06
         compiled from "/var/www/html/HEURIST/HEURIST_FILESTORE/Heurist_Shakespeare_Exemplar/smarty-templates/Images.tpl" */ ?>
<?php /*%%SmartyHeaderCode:160757978656cfb8aec69be7-27334890%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2a896e65f238248cdb3bebb1df497339391deeb6' => 
    array (
      0 => '/var/www/html/HEURIST/HEURIST_FILESTORE/Heurist_Shakespeare_Exemplar/smarty-templates/Images.tpl',
      1 => 1455762423,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '160757978656cfb8aec69be7-27334890',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>

<?php  $_smarty_tpl->tpl_vars['r'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('results')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['r']->key => $_smarty_tpl->tpl_vars['r']->value){
?> 

  [ <?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>
 ] 
<?php echo $_smarty_tpl->tpl_vars['r']->value['file_path'];?>
 /
<b><?php echo $_smarty_tpl->tpl_vars['r']->value['file_name'];?>
</b><br/>
<?php echo smarty_function_wrap(array('var'=>$_smarty_tpl->tpl_vars['r']->value['file_resource_originalvalue'],'dt'=>"file",'width'=>"300",'height'=>"auto"),$_smarty_tpl);?>
<br/>
 
   <hr> <!-- add line between each record -->

<?php }} ?> 
