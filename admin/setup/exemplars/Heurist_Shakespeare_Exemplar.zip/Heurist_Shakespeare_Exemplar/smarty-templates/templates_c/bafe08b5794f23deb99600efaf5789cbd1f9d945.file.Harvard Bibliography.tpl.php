<?php /* Smarty version Smarty-3.0.7, created on 2012-08-16 16:07:59
         compiled from "/var/www/htdocs/HEURIST_FILESTORE/searle_decra1/smarty-templates/Harvard Bibliography.tpl" */ ?>
<?php /*%%SmartyHeaderCode:851359630502c8e3f7314b8-73330165%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bafe08b5794f23deb99600efaf5789cbd1f9d945' => 
    array (
      0 => '/var/www/htdocs/HEURIST_FILESTORE/searle_decra1/smarty-templates/Harvard Bibliography.tpl',
      1 => 1344486892,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '851359630502c8e3f7314b8-73330165',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<?php  $_smarty_tpl->tpl_vars['r'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('results')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['r']->key => $_smarty_tpl->tpl_vars['r']->value){
?>

<?php if (($_smarty_tpl->tpl_vars['r']->value['recTypeName']=="Internet bookmark")){?>
      <?php echo $_smarty_tpl->tpl_vars['r']->value['date'];?>
 <?php echo $_smarty_tpl->tpl_vars['r']->value['title_name'];?>
 [Web site]<br/>
   <?php echo $_smarty_tpl->tpl_vars['r']->value['short_summary'];?>
<br/>

<?php }elseif($_smarty_tpl->tpl_vars['r']->value['recTypeName']=="Book"){?>
   </i><br>
   <?php  $_smarty_tpl->tpl_vars['Author_Editor'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['r']->value['Author_Editors']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['Author_Editor']->key => $_smarty_tpl->tpl_vars['Author_Editor']->value){
?>
      <?php echo ((mb_detect_encoding($_smarty_tpl->tpl_vars['Author_Editor']->value['title_name'], 'UTF-8, ISO-8859-1') === 'UTF-8') ? mb_strtoupper($_smarty_tpl->tpl_vars['Author_Editor']->value['title_name'],SMARTY_RESOURCE_CHAR_SET) : strtoupper($_smarty_tpl->tpl_vars['Author_Editor']->value['title_name']));?>
,
      <?php echo $_smarty_tpl->tpl_vars['Author_Editor']->value['given_names'];?>
,
      <?php }} ?>
   <?php echo $_smarty_tpl->tpl_vars['r']->value['year'];?>

   <i><?php echo $_smarty_tpl->tpl_vars['r']->value['title_name'];?>
</i>.
   <?php echo $_smarty_tpl->tpl_vars['r']->value['Publication_Series']['Publisher']['title_name'];?>
:
   <?php echo $_smarty_tpl->tpl_vars['r']->value['Publication_Series']['Publisher']['place_published'];?>
<br/> 

<?php }elseif($_smarty_tpl->tpl_vars['r']->value['recTypeName']=="Journal Article"){?>
   <?php  $_smarty_tpl->tpl_vars['Author_Editor'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['r']->value['Author_Editors']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['Author_Editor']->key => $_smarty_tpl->tpl_vars['Author_Editor']->value){
?>
      <?php echo $_smarty_tpl->tpl_vars['Author_Editor']->value['title_name'];?>
,
      <?php echo $_smarty_tpl->tpl_vars['Author_Editor']->value['given_names'];?>
,
      <?php }} ?>

 <i><?php echo $_smarty_tpl->tpl_vars['r']->value['Journal_volume']['recTitle'];?>
</i>

Does not come out: <?php echo $_smarty_tpl->getVariable('Journal_volume')->value['Journal']['Journal_Name'];?>
<br/>

 <?php echo $_smarty_tpl->tpl_vars['r']->value['Journal_volume']['volume'];?>


(
<?php echo $_smarty_tpl->tpl_vars['r']->value['Journal_volume']['Part']/'Issue';?>

)
: <?php echo $_smarty_tpl->tpl_vars['r']->value['start_page'];?>
-<?php echo $_smarty_tpl->tpl_vars['r']->value['end_page'];?>



  <br/>

<?php }else{ ?>

<?php echo ((mb_detect_encoding($_smarty_tpl->tpl_vars['r']->value['recTypeName'], 'UTF-8, ISO-8859-1') === 'UTF-8') ? mb_strtoupper($_smarty_tpl->tpl_vars['r']->value['recTypeName'],SMARTY_RESOURCE_CHAR_SET) : strtoupper($_smarty_tpl->tpl_vars['r']->value['recTypeName']));?>
 : Sorry, this record type is not supported by Harvard format : <?php echo $_smarty_tpl->tpl_vars['r']->value['recTitle'];?>
<br/>

<?php }?>

<hr/>
<?php }} ?>
