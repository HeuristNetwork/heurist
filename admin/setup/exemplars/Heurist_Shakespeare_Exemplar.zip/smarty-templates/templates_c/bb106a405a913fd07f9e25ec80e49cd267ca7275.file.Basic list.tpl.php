<?php /* Smarty version Smarty-3.0.7, created on 2014-02-21 19:41:57
         compiled from "/var/www/html/HEURIST_FILESTORE/searle_decra1/smarty-templates/Basic list.tpl" */ ?>
<?php /*%%SmartyHeaderCode:727719564530711553be371-67633590%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bb106a405a913fd07f9e25ec80e49cd267ca7275' => 
    array (
      0 => '/var/www/html/HEURIST_FILESTORE/searle_decra1/smarty-templates/Basic list.tpl',
      1 => 1357808094,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '727719564530711553be371-67633590',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<?php  $_smarty_tpl->tpl_vars['r'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('results')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['r']->key => $_smarty_tpl->tpl_vars['r']->value){
?> 

   <!-- Output some common fields -->
   <?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>

   <?php echo $_smarty_tpl->tpl_vars['r']->value['recTitle'];?>

   <?php echo $_smarty_tpl->tpl_vars['r']->value['recURL'];?>

   <?php echo $_smarty_tpl->tpl_vars['r']->value['recModified'];?>

   <?php echo $_smarty_tpl->tpl_vars['r']->value['recWootText'];?>


   <hr> <!-- add line between each record -->

<?php }} ?> 
