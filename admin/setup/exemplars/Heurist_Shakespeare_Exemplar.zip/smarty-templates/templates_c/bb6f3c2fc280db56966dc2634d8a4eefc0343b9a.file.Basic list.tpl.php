<?php /* Smarty version Smarty-3.0.7, created on 2016-02-26 13:29:47
         compiled from "/var/www/html/HEURIST/HEURIST_FILESTORE/Heurist_Shakespeare_Exemplar/smarty-templates/Basic list.tpl" */ ?>
<?php /*%%SmartyHeaderCode:37023634356cfb89b82bfc0-12234196%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bb6f3c2fc280db56966dc2634d8a4eefc0343b9a' => 
    array (
      0 => '/var/www/html/HEURIST/HEURIST_FILESTORE/Heurist_Shakespeare_Exemplar/smarty-templates/Basic list.tpl',
      1 => 1455762423,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '37023634356cfb89b82bfc0-12234196',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<?php  $_smarty_tpl->tpl_vars['r'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('results')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['r']->key => $_smarty_tpl->tpl_vars['r']->value){
?> 

   <!-- Output some common fields -->
   <?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>

   <?php echo $_smarty_tpl->tpl_vars['r']->value['recTitle'];?>

   <?php echo $_smarty_tpl->tpl_vars['r']->value['recURL'];?>

   <?php echo $_smarty_tpl->tpl_vars['r']->value['recModified'];?>

   <?php echo $_smarty_tpl->tpl_vars['r']->value['recWootText'];?>


   <hr> <!-- add line between each record -->

<?php }} ?> 
