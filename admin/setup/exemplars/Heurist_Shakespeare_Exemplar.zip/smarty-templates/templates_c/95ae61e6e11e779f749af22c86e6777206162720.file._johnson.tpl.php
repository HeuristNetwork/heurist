<?php /* Smarty version Smarty-3.0.7, created on 2014-02-21 19:42:15
         compiled from "/var/www/html/HEURIST_FILESTORE/searle_decra1/smarty-templates/_johnson.tpl" */ ?>
<?php /*%%SmartyHeaderCode:187361285553071167098ee4-03018038%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '95ae61e6e11e779f749af22c86e6777206162720' => 
    array (
      0 => '/var/www/html/HEURIST_FILESTORE/searle_decra1/smarty-templates/_johnson.tpl',
      1 => 1392972135,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '187361285553071167098ee4-03018038',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>


<h2>Title for report</h2> 

<hr>
<?php  $_smarty_tpl->tpl_vars['r'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('results')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['r']->key => $_smarty_tpl->tpl_vars['r']->value){
?> 

   <?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>
 
   <?php echo $_smarty_tpl->tpl_vars['r']->value['recTitle'];?>
 

   <br/> 

<?php }} ?> 
<hr/>

<h2>End of report</h2> 
