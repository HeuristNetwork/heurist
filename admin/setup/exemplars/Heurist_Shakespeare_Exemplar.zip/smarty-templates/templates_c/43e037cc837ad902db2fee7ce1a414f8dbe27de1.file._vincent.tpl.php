<?php /* Smarty version Smarty-3.0.7, created on 2015-11-10 11:25:10
         compiled from "/var/www/html/HEURIST/HEURIST_FILESTORE/Shakespeares_Plays/smarty-templates/_vincent.tpl" */ ?>
<?php /*%%SmartyHeaderCode:90874901156413966358477-41758438%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '43e037cc837ad902db2fee7ce1a414f8dbe27de1' => 
    array (
      0 => '/var/www/html/HEURIST/HEURIST_FILESTORE/Shakespeares_Plays/smarty-templates/_vincent.tpl',
      1 => 1447115110,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '90874901156413966358477-41758438',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<html>


<h2>Title for report</h2> 
<hr>
<?php  $_smarty_tpl->tpl_vars['r'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('results')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['r']->key => $_smarty_tpl->tpl_vars['r']->value){
?> 
     <?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>
  
     <?php echo $_smarty_tpl->tpl_vars['r']->value['f1'];?>
       


<br/> 
<?php }} ?> 

<hr/>
<h2>End of report</h2>  
</html>
